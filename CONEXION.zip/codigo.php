<?php

$archivo = fopen("texto.txt","r")
or die("problemas con el archivo.txt");

while(!feof($texto)){
    $leer = fgets($texto);
    $saltarliena = nl2br($leer);
    echo $saltarliena;
}
?>