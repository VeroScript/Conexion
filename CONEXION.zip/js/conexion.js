var btnCARGAR = document.getElementById('cargando');

function cargarAjax(){
    alert("En proceso");
    var solicitud = new XMLHttpRequest(); //crear XMLHttpRequest

    solicitud.open("GET", "texto.txt", true); //abrimos conexion
    alert("Conectado");
    
    solicitud.onreadystatechange = function(){
        console.log(solicitud.readyState);
        if(solicitud.readyState = 4 && solicitud.status == 200){
            
            console.log("Conexion correcta");
            var contenido = document.getElementById('contenido');
            contenido.innerHTML = solicitud.responseText;
        }
    }
    solicitud.send();
}
btnCARGAR.addEventListener('click', cargarAjax);